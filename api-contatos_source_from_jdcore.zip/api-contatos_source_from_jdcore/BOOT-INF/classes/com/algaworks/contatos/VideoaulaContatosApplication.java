package com.algaworks.contatos;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideoaulaContatosApplication {
  public VideoaulaContatosApplication() {}
  
  public static void main(String[] args) {
    org.springframework.boot.SpringApplication.run(VideoaulaContatosApplication.class, args);
  }
}
